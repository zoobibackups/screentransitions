import React,{useRef} from 'react'
import {Text, View,ScrollView,TouchableOpacity,Animated, StyleSheet} from 'react-native'
import {ITEM_WIDTH, width,SPACING, ICON_SIZE} from '../config/theme'
import Icon from '../Components/Icon'
import BackIcon from '../Components/BackIcon'
import {DATA} from '../config/travel'
import {SafeAreaView} from 'react-native-safe-area-context'

import { SharedElement } from "react-navigation-shared-element";

const  Details =  ({navigation, route}) => {
    const {item} = route.params
 //   const item = DATA[0];
    const ref = useRef();
    const SelectedIndex = DATA.findIndex((i) => i.id === item.id);
    const mountedAnimated = useRef(new Animated.Value(0)).current;
    const ActiveIndex = useRef(new Animated.Value(SelectedIndex)).current;
    const ActiveIndexAnimation = useRef(new Animated.Value(SelectedIndex)).current;
    
    
    const animation = (toValue, delay) =>
        Animated.timing(
            mountedAnimated,{
                toValue,
                duration:500,
                delay,
                useNativeDriver:true 
            }
        )
    
    
    React.useEffect(() => {
        Animated.parallel([
            Animated.timing(ActiveIndexAnimation,{
                toValue:ActiveIndex,
                duration:300,
                useNativeDriver:true
            }),
            animation(1,500)
        ]).start()
    })
    const size = ICON_SIZE + SPACING * 2
    const translateY = mountedAnimated.interpolate({
        inputRange:[0,1],
        outputRange:[50,0]
    });

    const translateX = ActiveIndexAnimation.interpolate({
        inputRange:[-1,0,1],
        outputRange:[size,0, -size]
    });

    return(
        <SafeAreaView style={{flex:1}}>
            <BackIcon  
                onPress={() => {
                    animation(0).start(() => {
                        navigation.goBack()
                    })
                }}
            />
            <Animated.View 
                style={{
                    flexDirection:"row", 
                    flexWrap:"nowrap",
                    marginVertical:20,
                    width:(ITEM_WIDTH+SPACING)*DATA.length,
                 
                    transform:[{translateX}],
                    marginLeft:width/2 -ICON_SIZE /2 -SPACING
                }}>
                {DATA.map((item, index) => {
                    const inputRange  = [index -1 , index , index +1];
                    const opacity = ActiveIndexAnimation.interpolate({
                        inputRange,
                        outputRange:[.3,1,.3],
                        extrapolate:"clamp"
                    })
                    return (
                        <TouchableOpacity
                        onPress={() => {
                            console.log(index, 'Index')
                            
                            ActiveIndex.setValue(index)
                            ref.current.scrollToIndex({
                                index,
                                animated:true
                            })
                        }}
                            key={item.id}
                            style={{padding:SPACING,   }}
                            >
                            <Animated.View style={{alignItems:"center", opacity }}>
                                <SharedElement id={`item.${item.id}.icon`}>
                                    <Icon uri={item.imageUri} />
                                </SharedElement>
                                <Text style={{fontSize:12}}>{item.title}</Text>
                            </Animated.View>
                        </TouchableOpacity>
                    )}
                )}
            </Animated.View>
            <Animated.FlatList
                style={{opacity:mountedAnimated , transform:[{translateY}]}} 
                ref={ref}
                data={DATA}
                keyExtractor={(item) => item.id}
                horizontal
                pagingEnabled
                initialScrollIndex={SelectedIndex}
                nestedScrollEnabled
                getItemLayout={(data, index) => ({
                    length:width,
                    offset:width*index,
                    index
                })}
                showsVerticalScrollIndicator={false}
                contentContainerStyle={{paddingRight:width-ITEM_WIDTH-SPACING*2}}
                decelerationRate="fast"
                showsHorizontalScrollIndicator={false}
                onMomentumScrollEnd={ev => {
                    const newIndex = Math.floor(ev.nativeEvent.contentOffset.x / width);
                    ActiveIndex.setValue(newIndex)
                }}
                renderItem={({item}) => {
                    return(
                        <ScrollView 
                            showsVerticalScrollIndicator={false}
                            style={{
                                width:width -SPACING *2,
                                margin:SPACING,
                                backgroundColor:"rgba(0,0,0,.05)",
                                borderRadius:16,
                                padding:SPACING
                                }}
                        >
                            <View style={{padding:SPACING}}>
                                <Text style={{fontSize:16}}>
                                    {Array(50).fill(`${item.title} inner text \n`)}
                                </Text>

                            </View>
                        </ScrollView>
                    )
                }}
            />
        </SafeAreaView>

    )
}

// Details.sharedElements = (route, otherRoute, showing) => {
//     return DATA.map(item => `item.${item.id}.icon`)   
//   }

Details.sharedElements = (route, otherRoute, showing) => {
    return DATA.map(item => `item.${item.id}.icon`)   
  }

export default Details;

const styles = StyleSheet.create({
    itemContainer:{
        width:ICON_SIZE,
        maxHeight:ICON_SIZE, 
        marginHorizontal:SPACING/2, 
        marginTop:10,
        borderRadius:ICON_SIZE/2,
        padding:20, 
        overflow:"hidden",
    },
    itemtext:{
        color:"#fff",
        fontWeight:"bold",
        fontSize:18,
    }
})