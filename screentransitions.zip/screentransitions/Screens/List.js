import React, { useEffect, useRef } from "react";
import { Animated, Text,Dimensions, View, StyleSheet,Easing, TouchableOpacity, Button,Image } from "react-native";
import {SafeAreaView} from 'react-native-safe-area-context'
import AntDesign from 'react-native-vector-icons/AntDesign'
import MArketinfSlider from '../Components/MarketingSlider'
import {DATA} from '../config/travel'
import Icon from '../Components/Icon'
import { SharedElement } from "react-navigation-shared-element";
const SPACING = 3
const List = ({navigation, route}) => {
  return (
    <SafeAreaView style={{flex:1}}>
      <MArketinfSlider />
      <View
        style={{
          flexDirection:"row",
          flexWrap:"wrap",
          alignItems:"center",
          justifyContent:"center",
          marginVertical:20
        }}
      >
        {DATA.map((item) => {
         
          return(
            <TouchableOpacity
              key={item.id}
              style={{padding:SPACING}}
              onPress={() => {navigation.push('Details', {item})}}
              >
                <SharedElement id={`item.${item.id}.icon`}>
                    <Icon uri={item.imageUri} />
                </SharedElement>
            </TouchableOpacity>
           
          )
        })}
      </View>
    </SafeAreaView>
  );
}


export default List;