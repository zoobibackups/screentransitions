export const DATA = [
    {
        imageUri:"https://image.flaticon.com/icons/png/128/2990/2990502.png",
        title:"gittar",
        id:"2990502",
    },
    {
        imageUri:"https://image.flaticon.com/icons/png/128/2990/2990505.png",
        title:"sun",
        id:"2990505",
    },
    {
        imageUri:"https://image.flaticon.com/icons/png/128/2990/2990510.png",
        title:"banna",
        id:"2990510",
    },
    {
        imageUri:"https://image.flaticon.com/icons/png/128/2990/2990512.png",
        title:"Banna",
        id:"2990512",
    },
    {
        imageUri:"https://image.flaticon.com/icons/png/128/2990/2990589.png",
        title:"Fish",
        id:"2990547",
    },
    {
        imageUri:"https://image.flaticon.com/icons/png/128/2990/2990740.png",
        title:"Tower",
        id:"2990548",
    },
    {
        imageUri:"https://image.flaticon.com/icons/png/128/2990/2990763.png",
        title:"Bird",
        id:"2990549",
    },
    {
        imageUri:"https://image.flaticon.com/icons/png/128/2990/2990543.png",
        title:"Bikni",
        id:"2990550",
    },
    {
        imageUri:"https://image.flaticon.com/icons/png/128/2990/2990551.png",
        title:"Fruit",
        id:"2990551",
    },
    {
        imageUri:"https://image.flaticon.com/icons/png/128/2990/2990606.png",
        title:"Girl",
        id:"2990552",
    },
    {
        imageUri:"https://image.flaticon.com/icons/png/128/2990/2990688.png",
        title:"Chapl",
        id:"2990553",
    },
    {
        imageUri:"https://image.flaticon.com/icons/png/128/2990/2990758.png",
        title:"Malaye",
        id:"2990554",
    },
    

]

export const SLIDER_DATA = [
    {
        title:"Sunny Days ",
        color:"turquoise"
    },
    {
        title:"Sand & Beach",
        color:"aquamarine"
    },
    {
        title:"Coktails & Party",
        color:"tomato"
    },
    {
        title:"All Exclusive",
        color:"#A531F9"
    },
]