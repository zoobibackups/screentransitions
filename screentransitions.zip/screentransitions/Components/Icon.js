import React from 'react'
import {View, StyleSheet, Image} from 'react-native'
import {ICON_SIZE} from '../config/theme'

export default function Icon({uri}){
    return(
        <View style={[styles.imageContainer ]}>
            <Image  source={{uri}} style={[styles.image]} />
        </View>
    )
}

const styles = StyleSheet.create({
    imageContainer:{
        width:ICON_SIZE,
        height:ICON_SIZE,
        borderRadius:ICON_SIZE/2,
        borderColor:"#ddd",
        alignItems:"center",
        justifyContent:"center",
        backgroundColor:"#ddd"
    },
    image:{
        width:ICON_SIZE * .5,
        height:ICON_SIZE * .5,
        resizeMode:"contain",    }
})